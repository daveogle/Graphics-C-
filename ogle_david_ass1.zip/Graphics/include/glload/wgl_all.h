#ifndef WINDOWSGL_GEN_ALL_H
#define WINDOWSGL_GEN_ALL_H

#include "_int_wgl_type.h"
#include "_int_wgl_exts.h"

#endif /*WINDOWSGL_GEN_ALL_H*/

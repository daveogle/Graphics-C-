#ifndef OPENGL_GEN_1_0_HPP
#define OPENGL_GEN_1_0_HPP

#include "_int_gl_type.hpp"
#include "_int_gl_exts.hpp"

#include "_int_gl_1_0.hpp"
#endif /*OPENGL_GEN_1_0_HPP*/

#ifndef OPENGL_GEN_1_0_H
#define OPENGL_GEN_1_0_H

#include "_int_gl_type.h"
#include "_int_gl_exts.h"

#include "_int_gl_1_0.h"
#endif /*OPENGL_GEN_1_0_H*/
